//package com.iconmaster.source.link.platform.hppl;
//
//import com.iconmaster.source.prototype.SourcePackage;
//
///**
// *
// * @author iconmaster
// */
//public class HPPLAssembler {
//	public static String assemble(SourcePackage pkg) {
//		//StringBuilder sb = new StringBuilder("#pragma mode( separator(.,;) integer(h32) )\n\n//This program compiled with Source: www.github.com/iconmaster5326/Source\n\n");
//		
//		return "";
//	}
//}
