//package com.iconmaster.source.link.platform.hppl;
//
//import java.util.HashSet;
//
///**
// *
// * @author iconmaster
// */
//public class AssembleVarSpace {
//	HashSet<String> vars = new HashSet<>();
//	HashSet<String> defs = new HashSet<>();
//	HashSet<String> consts = new HashSet<>();
//}
